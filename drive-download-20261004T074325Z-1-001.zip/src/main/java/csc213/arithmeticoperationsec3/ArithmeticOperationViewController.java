package csc213.arithmeticoperationsec3;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ArithmeticOperationViewController
{
    @javafx.fxml.FXML
    private TextField xTextField;
    @javafx.fxml.FXML
    private Label outputLabel;
    @javafx.fxml.FXML
    private TextField yTextField;
    @javafx.fxml.FXML
    private Button addButton;

    int val;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void addButtonOnMouseClicked(Event event) {

        //..,.. AFTER BREAK
        String xStr = xTextField.getText();     // "12"
        String yStr = yTextField.getText();     // "13"

        //  xStr + yStr;                        // "1213"
        int xVal = Integer.parseInt(xStr);      // int 12
        int yVal = Integer.parseInt(yStr);      // int 13

        int sum = xVal + yVal;                  // int 25
        String sumStr = Integer.toString(sum);  // "25"

        //outputLabel.setText("X + Y = " + sumStr);
        outputLabel.setText("X + Y = " + sum);
    }

    @javafx.fxml.FXML
    public void subtractButtonOnAction(ActionEvent actionEvent) {
        outputLabel.setText(
                "X - Y = "
                +
                Integer.toString(
                     Integer.parseInt(xTextField.getText())
                                        -
                     Integer.parseInt(yTextField.getText())
                )
        );
    }

    @javafx.fxml.FXML
    public void addButtonOnMouseExited(Event event) {
        addButton.setText("Add");
    }


    @javafx.fxml.FXML
    public void addButtonOnMouseEntered(Event event) {
        addButton.setText("Click Me!");
    }
}
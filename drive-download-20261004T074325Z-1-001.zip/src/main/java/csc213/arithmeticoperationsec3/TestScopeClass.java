package csc213.arithmeticoperationsec3;

public class TestScopeClass {

    public void testScope(){

        DummyClass d = new DummyClass();

        int x = d.publicField;
        //int y = d.privateField;

        d.doSome();
        //d.doAnother();

    }


}

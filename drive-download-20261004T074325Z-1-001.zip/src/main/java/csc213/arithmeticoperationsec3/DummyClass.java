package csc213.arithmeticoperationsec3;

public class DummyClass {

    private int privateField;
    public int publicField;

    public void doSome(){
        System.out.println("Doing something");
        System.out.println(privateField);
        System.out.println(publicField);
        doAnother();
    }

    private void doAnother(){
        System.out.println("Doing another thing");

    }

}

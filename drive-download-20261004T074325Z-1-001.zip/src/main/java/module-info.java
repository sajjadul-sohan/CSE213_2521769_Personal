module csc213.arithmeticoperationsec3 {
    requires javafx.controls;
    requires javafx.fxml;


    opens csc213.arithmeticoperationsec3 to javafx.fxml;
    exports csc213.arithmeticoperationsec3;
}